import java.net.*;
import java.io.*;

class UDPclient
{
	final static int ECHO_PORT=7;
	DatagramPacket dp;
	DatagramSocket ds;
	byte msg=new byte[1024];
	String msgreceived;
	
	try{
		