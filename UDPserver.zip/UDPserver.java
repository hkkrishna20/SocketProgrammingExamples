// writing client server program using UDP

import java.net.*;
import java.io.*;


class UDPserver
{
	final static int ECHO_PORT=7;
	public static void main(String args[])
	{
		DatagramSocket ds;
		DatagramPacket dp;
		
		try{
		   	ds=new DatagramSocket(ECHO_PORT);
		   	while(true){
				dp=new DatagramPacket(new byte[1024],1024);
				ds.receive(dp);
				dp=new DatagramPacket(dp.getData(),		
					dp.getLength(),dp.getAddress(),dp.getPort());
				ds.send(dp);
			}
		}catch(IOException e){
			System.out.println("could not recieve or send data");
		 }
	 }
}
		 
			
				


