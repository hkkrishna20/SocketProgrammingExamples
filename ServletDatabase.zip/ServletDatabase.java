import javax.servlet.*;
import java.sql.*;

public class ServletDatabase extends GenericServlet
{
	Connection con;
	PreparedStatement prst;
	ResultSer rs;
	public void init(ServletConfig sc)
	{
		try
		{
			Class.forName("jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("Jdbc:Odbc:stud","eml","");
			super.init(sc);
		}
		catch(Exception e)
		{
			System.out.println(e.getString());
		}
	}
	
	public void service(SrevletRequest req,ServletResponse res)
	{
		try
		{
			res.setContextType("text/html");
			String s1 = req.getParameter("login");
			String s2 = req.getParameter("password");
			prst = con.PreparedStatement("Select eno,ename,desig,sal from emp where	
							login=? password=?");
			ServletOutputStream sos = res.getOutputStream();
			rs = prst.executeQuery();
			if(rs.next())
			{
				int eno = rs.getInt(3);
				String name = rs.getString(4);
				String desig = rs.getString(5);
				float sal = rs.getFloat(6);
				sos.println("Employee No"+eno);
				sos.println("Employee Name"+name);
				sos.println("Designation"+desig);
				sos.println("Salary"+sal);	
			}
			else
			{
				sos.println("You are not a valid user, please try again");
			}
		}
		
			
	}
}
	