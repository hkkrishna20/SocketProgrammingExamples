import java.util.*;
import java.io.*;
import java.net.*;

public class servertest 
{
	final static int SERVER_PORT = 8001;
	public static void main(String a[])
	{
		Server server;
		String creq,sr;
		BufferedReader reader,read;
		PrintWriter writer,write;

		server = new Server(SERVER_PORT);
		reader = new BufferedReader(new InputStreamReader(server.in));
		writer = new PrintWriter(new OutputStreamWriter(server.out),true);
		read = new BufferedReader(new InputStreamReader(System.in));
		write = new PrintWriter(new OutputStreamWriter(System.out),true);

		writer.println("Java Test Server " + new Date());

		while(true) 
		{
			try {

				creq = reader.readLine();
				System.out.println("Client says : " + creq);
				sr = read.readLine();
				writer.println(sr);
				/*if(creq.equals("hai"))
					writer.println("i am venkatesh");*/
				if(creq.equals("quit"))
					System.exit(0);
			}catch(IOException e) {
				System.out.println("Exception caught");
			}
		}
	}
}

class Server 
{
	private ServerSocket server;
	private Socket socket;

	public InputStream in;
	public OutputStream out;

	public Server(int port) 
	{
		try {
			server = new ServerSocket(port);
			System.out.println("ServerSocket before accept : "+server);
			System.out.println("Java test server on-line");

			socket = server.accept();
			System.out.println("ServerSocket after accept : "+server);

			in = socket.getInputStream();
			out = socket.getOutputStream();
		}catch(IOException e) {
			System.out.println("caught server constructor");
		}
	}
}


